'use client'
import ReservationPane from "@/components/ReservationPane"

export default function reservationslist () {
    return (
        <main>
            <ReservationPane/>
        </main>
    )
}
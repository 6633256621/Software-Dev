'use client'
import RestaurantPannel from "@/components/RestaurantPannel"

export default function MyBookingPage () {
    return (
        <main>
            <RestaurantPannel></RestaurantPannel>
        </main>
    )
}
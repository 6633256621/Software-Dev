const { app, BrowserWindow } = require('electron');
const url = require('url');
const path = require('path');

require('@electron/remote/main').initialize();

function createMainWindow() {
    const mainWindow = new BrowserWindow({
        icon: path.join(__dirname, 'public', 'logo.jpg'),
        width: 1000,
        height: 600,
        title: 'Boss HardWare',
        webPreferences: {
            contextIsolation: true,
            preload: path.join(__dirname, 'preload.js'),
            enableRemoteModule: true,
            reloadOnRestart: false,
            nodeIntegration: true,
        }
    });
    mainWindow.webContents.on('did-navigate-in-page', (event, url) => {
        mainWindow.setTitle('Boss HardWare') // Update the title on navigation
      })

    const startUrl = url.format({
        pathname: path.join(__dirname, './build/index.html'),
        protocol: 'file',
    });

    mainWindow.loadURL('http://localhost:3000');
}

app.whenReady().then(createMainWindow);

app.on('window-all-closed', function () {
    console.log('All windows closed');
    app.quit();
});

app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) {
        createMainWindow();
    }
    
});
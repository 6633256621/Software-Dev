
export default async function addIcecream(flavor:string,price:number) {
    console.log(JSON.stringify({ flavor, price }))
    let url =  `${process.env.REACT_APP_BACKEND_URL}/api/icecream`;
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ flavor, price }),
        });
        if (!response.ok) {
            throw new Error('Cannot add icecreams');
        }
        return await response.json();
        }
        catch (error) {
            console.error('Error fetching icecreams:', error);
            throw error; // Rethrow the error for the caller to handle
        }
    
}

export default async function getOneIcecream(id: string) {
    let url =  `${process.env.REACT_APP_BACKEND_URL}/api/icecream/${id}`;
    try {
        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        });
        if (!response.ok) {
            throw new Error('Failed to fetch icecreams');
        }
        return await response.json();       
    } catch (error) {
        console.error('Error fetching icecreams:', error);
        return null;
    }
}
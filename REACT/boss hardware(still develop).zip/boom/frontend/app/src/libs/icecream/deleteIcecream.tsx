
export default async function deleteIcecream(id: string) {
    let url = `${process.env.REACT_APP_BACKEND_URL}/api/icecream/${id}`;
    try {
        const response = await fetch(url, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            },
        });
        if (!response.ok) {
            throw new Error('Failed to delete icecream');
        }
        return await response.json();
    } catch (error) {
        console.error('Error fetching icecreams:', error);
    }
}
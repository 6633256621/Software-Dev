export default async function updateProduct(id: string, name: string, type: string, URL: string,target:string) {
    let url = `${process.env.REACT_APP_BACKEND_URL}/api/product/${target}`;
    try {
        const response = await fetch(url, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id,name, type, URL }),
        });
        if (!response.ok) {
            throw new Error('Cannot update product');
        }
        return await response.json();
    } catch (error) {
        console.error('Error updating product:', error);
        throw error; // Rethrow the error for the caller to handle
    }
}

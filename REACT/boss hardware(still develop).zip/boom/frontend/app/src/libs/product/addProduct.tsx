
export default async function addProduct(name:string,type:string,URL:string
) {
    let url =  `${process.env.REACT_APP_BACKEND_URL}/api/product`;
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name,type,URL,history:[] }),
        });
        if (!response.ok) {
            throw new Error('Cannot add product');
        }
        return await response.json();
        }
        catch (error) {
            console.error('Error fetching product:', error);
            throw error; // Rethrow the error for the caller to handle
        }
    
}

export default async function getAllProduct() {
    let url =  `${process.env.REACT_APP_BACKEND_URL}/api/products`;
    try {
        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        });
        if (!response.ok) {
            throw new Error('Failed to fetch products');
        }
        return await response.json();       
    } catch (error) {
        console.error('Error fetching products:', error);
        throw error; // Rethrow the error for the caller to handle
    }
}
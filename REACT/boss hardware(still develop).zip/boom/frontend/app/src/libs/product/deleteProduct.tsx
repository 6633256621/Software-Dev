export default async function deleteProduct(id: string) {
    const url = `${process.env.REACT_APP_BACKEND_URL}/api/product/${id}`;
    try {
        const response = await fetch(url, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            }
        });
        if (!response.ok) {
            throw new Error('Failed to delete product');
        }
        return await response.json();       
    } catch (error) {
        console.error('Error deleting product:', error);
        throw error; // Rethrow the error for the caller to handle
    }
}

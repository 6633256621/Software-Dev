
export default async function getOneProduct(id: any) {
    let url =  `${process.env.REACT_APP_BACKEND_URL}/api/product/${id}`;
    try {
        const response = await fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        });
        if (!response.ok) {
            throw new Error('Failed to fetch product');
        }
        return await response.json();       
    } catch (error) {
        console.error('Error fetching product:', error);
        return null;
    }
}
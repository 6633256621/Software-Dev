import React from "react";
import { Outlet } from "react-router-dom";

export const Layout: React.FC = () => {
  return (
    <div className="bg-gray-100 min-h-screen flex flex-col">
      <div className="navbar bg-neutral text-neutral-content">
      <div className="navbar-start">
      <div className="dropdown">
      <div tabIndex={0} role="button" className="btn btn-ghost btn-circle">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h7" /></svg>
      </div>
      <ul tabIndex={0} className="text-black menu menu-sm dropdown-content mt-3 z-[1] p-2 shadow bg-base-100 rounded-box w-52">
        <li><a href="#/">Homepage</a></li>
        <li><a href="#/product">Product</a></li>
        <li><a  href="#/account">Account</a></li>
        <li><a  href="#/icecream">Icecream</a></li>
      </ul>
    </div>
    
        </div>
        <div className="navbar-center">
    <p className="btn btn-ghost text-xl">Boss Hardware</p>
  </div>
  <div className="navbar-end">
  <div className="dropdown dropdown-end">
      <div tabIndex={0} role="button" className="btn btn-ghost btn-circle avatar">
        <div className="w-10 rounded-full">
          <img alt="Tailwind CSS Navbar component" src="https://img.daisyui.com/images/stock/photo-1534528741775-53994a69daeb.jpg" />
        </div>
      </div>
      <ul tabIndex={0} className="text-black mt-3 z-[1] p-2 shadow menu menu-sm dropdown-content bg-base-100 rounded-box w-52">
        <li>
          <p className="justify-between">
            Profile
            <span className="badge">New</span>
          </p>
        </li>
        <li><p>Settings</p></li>
        <li><p>Logout</p></li>
      </ul>
    </div>
  </div>
      </div>
      <main className="">
        <Outlet />
      </main>
    </div>
  );
};

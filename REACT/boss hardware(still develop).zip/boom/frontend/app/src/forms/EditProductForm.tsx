import React from "react";
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { ProductItem } from "../../interface";
import { useState,useEffect } from "react";
import { useParams } from "react-router-dom";
import getOneProduct from "../libs/product/getOneProduct";
import updateProduct from "../libs/product/updateProduct";

export const EditProductForm: React.FC = () => {
const [success,setSuccess] = useState(false);
const { id } = useParams<{ id: string }>(); // Get product ID from URL params
const [product, setProduct] = useState<ProductItem | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const productData = await getOneProduct(id); // Fetch product details by ID
        setProduct(productData);
      } catch (error) {
        console.error("Fetch error:", error);
      }
    };
    fetchData();
  }, [id]);


    const initialValues:ProductItem = {
        
        id:product?.id ?? '',
        name:product?.name ?? '',
        type:product?.type ?? '',
        URL:product?.URL ?? '',
        history:product?.history ?? [
            {
                company:'',
                date:'',
                discount:0,
                price:0,
                quan:0
            }
        ]
        
    };
    const validationSchema = Yup.object().shape({
    });
    const handleSubmit = async (values: ProductItem) => {
        try {
            let updatedName = values.name || initialValues.name;
            let updatedType = values.type || initialValues.type;
            let updatedURL = values.URL || initialValues.URL;

    
            await updateProduct(updatedName,updatedName, updatedType, updatedURL,initialValues.name);
            setSuccess(true);
        } catch (error) {
            console.error('Error updating product:', error);
            // Handle error appropriately
        }
    };
    
    return (
        <div className="flex flex-col gap-2">
            <div>
            <Formik initialValues={initialValues} onSubmit={ handleSubmit} validationSchema={validationSchema}>
                <Form className="">
                  <div className="flex flex-row gap-2">
                        <Field
                            type="text"
                            name="name"
                            placeholder= {product?.name}
                            className="input input-bordered w-full max-w-xs"
                        />
                        <ErrorMessage name="name" component="div" className="text-red-500" />
                        <Field
                            type="text"
                            name="type"
                            placeholder={product?.type}
                            className="input input-bordered w-full max-w-xs"
                        />
                        <ErrorMessage name="type" component="div" className="text-red-500" />
                        <Field
                            type="text"
                            name="URL"
                            placeholder={product?.URL}
                            className="input input-bordered w-full max-w-xs"
                        />
                        <ErrorMessage name="URL" component="div" className="text-red-500" />
                        <button type="submit" className="btn btn-primary">
                            Submit
                        </button>
                    </div>
                </Form>
            </Formik>
            </div>
            {success && <div className="text-green-500">Edit Product Success!</div>}
        </div>
    )
}
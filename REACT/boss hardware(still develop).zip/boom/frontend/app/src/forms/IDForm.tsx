import React from "react";
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';

interface IDFormProps {
    onSubmit: (id: string) => void; // Define the onSubmit prop function
}


export const IDForm: React.FC<IDFormProps> = ({ onSubmit }) => {
    interface IValue {
        id : string;
    }
    const initialValues:IValue = {
        id:''
    };
    const validationSchema = Yup.object().shape({
        id: Yup.string().required('ID is required'),
    })
    return (
        <div>
            <Formik initialValues={initialValues} onSubmit={(values) => onSubmit(values.id)} validationSchema={validationSchema}>
                <Form className="">
                  <div className="flex gap-2">
                        <Field
                            type="text"
                            name="id"
                            placeholder="Enter icecream ID"
                            className="input input-bordered w-full max-w-xs"
                        />
                        <ErrorMessage name="description" component="div" className="text-red-500" />
                        <button type="submit" className="btn btn-primary">
                            Submit
                        </button>
                    </div>
                </Form>
            </Formik>
        </div>
    )
}
import React from "react";
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { IcecreamItem } from "../../interface";
import addIcecream from "../libs/icecream/addIcecream";

export const CreateForm: React.FC = () => {

    const initialValues:IcecreamItem = {
        flavor:'',
        price:'0'
    };
    const validationSchema = Yup.object().shape({
        flavor: Yup.string().required('Flavor is required'),
        price: Yup.number().required('Price is required'),
    });
    const handleSubmit = (values: IcecreamItem) => {
        if (values.flavor !== '' && !isNaN(parseFloat(values.price))) {
            addIcecream(values.flavor, parseFloat(values.price)); // Pass price as a number
            window.location.reload();
        }
    };
    
    return (
        <div>
            <Formik initialValues={initialValues} onSubmit={ handleSubmit} validationSchema={validationSchema}>
                <Form className="">
                  <div className="flex gap-2">
                        <Field
                            type="text"
                            name="flavor"
                            placeholder="Enter icecream Flavor"
                            className="input input-bordered w-full max-w-xs"
                        />
                        <ErrorMessage name="flavor" component="div" className="text-red-500" />
                        <Field
                            type="number"
                            name="price"
                            placeholder="Enter icecream Price"
                            className="input input-bordered w-full max-w-xs"
                        />
                        <ErrorMessage name="price" component="div" className="text-red-500" />
                        <button type="submit" className="btn btn-primary">
                            Submit
                        </button>
                    </div>
                </Form>
            </Formik>
        </div>
    )
}
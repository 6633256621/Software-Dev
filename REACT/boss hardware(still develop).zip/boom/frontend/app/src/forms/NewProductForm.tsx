import React from "react";
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { ProductItem } from "../../interface";
import addProduct from "../libs/product/addProduct";
import { useState } from "react";

export const NewProductForm: React.FC = () => {
const [success,Setsuccess] = useState(false);
    const initialValues:ProductItem = {
        id:'',
        name:'',
        type:'',
        URL:'',
        history:[
            {
                company:'',
                date:'',
                discount:0,
                price:0,
                quan:0
            }
        ]
    };
    const validationSchema = Yup.object().shape({
        name: Yup.string().required('Name is required'),
        type: Yup.string().required('Type is required'),
        URL: Yup.string().required('URL is required')
    });
    const handleSubmit = (values: ProductItem) => {
        addProduct(values.name,values.type,values.URL)
            window.location.reload();
            Setsuccess(true);
    };
    
    return (
        <div className="flex flex-col gap-2">
            <div>
            <Formik initialValues={initialValues} onSubmit={ handleSubmit} validationSchema={validationSchema}>
                <Form className="">
                  <div className="flex flex-row gap-2">
                        <Field
                            type="text"
                            name="name"
                            placeholder="Enter product name"
                            className="input input-bordered w-full max-w-xs"
                        />
                        <ErrorMessage name="name" component="div" className="text-red-500" />
                        <Field
                            type="text"
                            name="type"
                            placeholder="Enter product type"
                            className="input input-bordered w-full max-w-xs"
                        />
                        <ErrorMessage name="type" component="div" className="text-red-500" />
                        <Field
                            type="text"
                            name="URL"
                            placeholder="Enter URL"
                            className="input input-bordered w-full max-w-xs"
                        />
                        <ErrorMessage name="URL" component="div" className="text-red-500" />
                        <button type="submit" className="btn btn-primary">
                            Submit
                        </button>
                    </div>
                </Form>
            </Formik>
            </div>
            {success && <div className="text-green-500">Add Product Success!</div>}
        </div>
    )
}
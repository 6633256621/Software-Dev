// ProductDetail.tsx
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom"; // Import useParams hook
import getOneProduct from "../libs/product/getOneProduct"; // Import function to fetch product by ID
import { ProductItem } from "../../interface";
import deleteProduct from "../libs/product/deleteProduct";

export const ProductDetail: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>(); // Get product ID from URL params
  const [product, setProduct] = useState<ProductItem | null>(null);
  const goToEdit = () => {
    navigate(`/product/${id}/edit`);
};

  useEffect(() => {
    const fetchData = async () => {
      try {
        const productData = await getOneProduct(id); // Fetch product details by ID
        setProduct(productData);
      } catch (error) {
        console.error("Fetch error:", error);
      }
    };
    fetchData();
  }, [id]);

  if (!product) {
    return <div>Loading...</div>;
  }

  return (
    <div className="flex gap-2">
      <div className="card h-1/2 w-1/3 bg-base-100 shadow-xl">
        <figure>
          <img src={product.URL} alt="" />
        </figure>
        <div className="card-body">
          <h2 className="card-title">Name : {product.name}</h2>
          <p>Type: {product.type}</p>
        </div>
        <div className="card-actions flex justify-between pb-2">
        <button className="btn btn-warning ml-2" onClick={goToEdit}>Edit Product</button>
        <button className="btn btn-error mr-2" onClick={async () => {
              try {
                await deleteProduct(product.id);
                navigate("/product");
              } catch (error) {
                console.error("Delete error:", error);
              }
            }}>Delete Product</button>
        </div>
      </div>
      <div>
        <table className="table table-zebra">
          <thead>
            <tr>
              <th></th>
              <th>Date</th>
              <th>Company</th>
              <th>Price</th>
              <th>Quantity</th>
              <th>Discount</th>
            </tr>
          </thead>
          <tbody>
            {product.history.map((historyItem, i) => (
              <tr>
                <th>{i + 1}</th>
                <td>{historyItem.date}</td>
                <td>{historyItem.company}</td>
                <td>{historyItem.price} ฿</td>
                <td>{historyItem.quan} PCS</td>
                <td>{historyItem.discount}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ProductDetail;

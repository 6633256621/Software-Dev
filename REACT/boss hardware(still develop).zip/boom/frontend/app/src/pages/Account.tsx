import React from "react";

export const Account:React.FC = () => {

    return (
        <div>
        </div>
    )
}
import React, { useState, useEffect } from "react";
import getAllIcecream from "../libs/icecream/getAllIcecream";
import { IDForm } from "../forms/IDForm";
import getOneIcecream from "../libs/icecream/getOneIcecream";
import { IcecreamItem } from "../../interface";
import {CreateForm} from "../forms/CreateForm";
import deleteIcecream from "../libs/icecream/deleteIcecream";

export const Icecream: React.FC = () => {
    const [icecreams, setIcecreams] = useState<any[]>([]);
    const [icecream, setIcecream] = useState<IcecreamItem | null>(null);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const icecreamsData = await getAllIcecream();
                setIcecreams(icecreamsData);
            } catch (error) {
                console.error('Fetch error:', error);
            }
        };

        fetchData();
    }, []);

    const getOneFormSubmit = async (id: string) => {
      try {
          const icecreamData = await getOneIcecream(id);
          setIcecream(icecreamData);
      } catch (error) {
          console.error('Fetch error:', error);
      }
  };
  const deleteFormSubmit = async (id: string) => {
    try {
        await deleteIcecream(id);
        window.location.reload();
    } catch (error) {
        console.error('Delete error:', error);
    }
};

    return (
        <div>
            <h1>Ice Cream List</h1>
            Count : {icecreams.length}
            <ul>
                {icecreams.map((eachIcecream, index) => (
                    <li key={index}>
                      <div className="flex gap-2">
                        <div>ID : {eachIcecream.id} ,</div>
                        <div>Icecream Flavor : {eachIcecream.flavor}</div>
                      </div>
                    </li>
                ))}
            </ul>
            <hr className="border-t-3 border-black my-8" />
            <div>
                Get One
              <IDForm onSubmit={getOneFormSubmit}/>
              {icecream !== null && (
                    <div className="flex flex-col gap-2">
                        <h2>Ice Cream Flavor : {icecream.flavor}</h2>
                        <h2>Ice Cream Price : {icecream.price}</h2>
                    </div>
                )}
                {icecream === null && <p>N/A</p>}
            </div>
            <hr className="border-t-3 border-black my-8" />
            <div>
                Create
                <CreateForm/>
            </div>
            <hr className="border-t-3 border-black my-8" />
            <div>
                Delete
            <IDForm onSubmit={deleteFormSubmit}/>
            </div>
        </div>
    )
}

import {NewProductForm} from "../forms/NewProductForm";

export const AddProduct:React.FC = () => {
    return (
        <div>
            <NewProductForm/>
        </div>
    )
}
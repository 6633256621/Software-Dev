import React, { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom";
import getAllProduct from "../libs/product/getAllProduct"
import {ProductItem} from "../../interface"
export const Product:React.FC = () => {
const [products,setProducts] = useState<any[]>([]);
const navigate = useNavigate();

useEffect(() => {
    const fetchData = async () => {
        try {
            const response = await getAllProduct();
            const productsData: ProductItem[] = response.Items;
            const sortedProducts = productsData.map(product => ({
                ...product,
                history: product.history.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
            }));
            setProducts(sortedProducts);
        } catch (error) {
            console.error('Fetch error:', error);
        }
    };
    fetchData();
},[]);
const goToProductDetail = (id: string) => {
    navigate(`/product/${id}`);
};

    return (
        <div className="flex flex-col gap-2">
            <div className="flex justify-between items-center mb-4">
                <div>
                    <h1>Product List</h1>
                    Count : {products.length}
                </div>
                <div className="align-right">
                    <button className="btn btn-primary" onClick={() => goToProductDetail('new')}>Add Product</button>
                </div>
            </div>
            
            <ul className="space-y-2">
                {products.map((eachProduct:ProductItem, index: number) => (
                    <li key={index}>
                      <div className="collapse bg-slate-200 gap-2">
                      <input type="radio" name="my-accordion-1" /> 
                        <div className="collapse-title text-xl font-medium">Product Name : {eachProduct.name}</div>
                        <div className="collapse-content"> 
                        <ul>
                        <div className="space-y-2">
                                        <table className="table table-zebra">
                                            <thead>
                                            <tr>
                                                <th>
                                                </th>
                                                <th>Date</th>
                                                <th>Company</th>
                                                <th>Price</th>
                                                <th>Quantity</th>
                                                <th>Discount</th>                                                
                                            </tr>
                                            </thead>
                                            <tbody>
                                            {eachProduct.history.map((historyItem, i) => (
                                    <tr>
                                        <th>{i+1}</th>
                                        <td>{historyItem.date}</td>
                                        <td>{historyItem.company}</td>
                                        <td>{historyItem.price} ฿</td>
                                        <td>{historyItem.quan} PCS</td>
                                        <td>{historyItem.discount}%</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        <button className="btn btn-primary" onClick={() => goToProductDetail(eachProduct.id)}>View Details</button>
                        </div>
                        </ul>
                        </div>
                      </div>
                    </li>
                ))}
            </ul>
        </div>
    );
};



export const Homepage: React.FC = () => {
    return (
        <div className="relative w-full h-screen">
            <div className="absolute inset-0 w-full h-full bg-cover bg-center"
                 style={{ backgroundImage: "url('/img/homepage.png')", opacity: 0.8 }}>
            </div>
        </div>
    );
};
import { EditProductForm } from "../forms/EditProductForm"

export const EditProduct:React.FC = () => {
    return (
        <div>
            <EditProductForm/>
        </div>
    )
}
export interface IcecreamItem {
    flavor: string;
    price: string;// it is a number but i have to type string Formik form is too stupid ngl
}

export interface ProductItem {
    id: string;
    name: string;
    type: string;
    URL:string;
    history: {
      company: string;
      date: string;
      discount: number;
      price: number;
      quan:number;
    }[];
  }
const { data } = require('autoprefixer');
const { channel } = require('diagnostics_channel');
const {contextBridge, ipcRenderer} = require('electron');

const os = require('os');

function getIPAddress() {
    const interfaces = os.networkInterfaces();
    for (const iface of Object.values(interfaces)) {
        for (const { address, family, internal } of iface) {
            if (family === 'IPv4' && !internal) {
                return address;
            }
        }
    }
    return 'No IP address found';
}

contextBridge.exposeInMainWorld('electron', {
    homeDir: () => os.homedir(),
    osVersion: () => os.version(),
    arch: () => os.arch(),
    ip:() => getIPAddress(),
});
contextBridge.exposeInMainWorld('ipcRenderer', {
    send: (channel,data) => ipcRenderer.send(channel,data),
    on: (channel,func) => ipcRenderer.on(channel,(event,...args) => func(...args)),
})
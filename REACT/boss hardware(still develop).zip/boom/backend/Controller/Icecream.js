const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
const {icecreamSchema, validateIcecreamItem} = require('../model/Icecream');
const { v4: uuidv4 } = require('uuid');

class IcecreamController {
    async getAllIcecreams(req, res, next) {
        const params = {
            TableName: icecreamSchema.TableName,
            Select: 'ALL_ATTRIBUTES',
        };

        try {
            const data = await docClient.scan(params).promise();
            const sortedItems = data.Items.sort((a, b) => {
                return a.id.localeCompare(b.id); // Assuming 'id' is a string attribute
            });
            res.json(sortedItems);
        } catch (err) {
            console.error('Unable to scan DynamoDB table:', err);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

    async getOneIcecream(req, res, next) {
        const { id } = req.params;

        const params = {
            TableName: icecreamSchema.TableName,
            Key: {
                id: id
            }
        };

        try {
            const data = await docClient.get(params).promise();
            if (!data.Item) {
                return res.status(404).json({ error: 'Ice cream not found' });
            }
            res.json(data.Item);
        } catch (err) {
            console.error('Unable to get ice cream from DynamoDB:', err);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

    async addOneIcecream(req, res, next) {
        const itemId = uuidv4();
        try {
        const icecreamItem = req.body;
            
        const isValidIcecreamItem = validateIcecreamItem(icecreamItem);
        if (!isValidIcecreamItem) {
            return res.status(400).json({
                success: false,
                message: 'Invalid ice cream item attributes'
            });
        }

        const existingIcecream = await docClient.get({
            TableName: icecreamSchema.TableName,
            Key: { id: itemId }
        }).promise();
        
        if (existingIcecream.Item) {
            return res.status(400).json({
                success: false,
                message: `Ice cream with ID '${icecreamItem.id}' already exists`
            });
        }

        icecreamItem.id = itemId;

        const params = {
            TableName: icecreamSchema.TableName,
            Item: icecreamItem
        };
        await docClient.put(params).promise();
        res.status(201).json({
            success: true,
            message: 'Ice cream added successfully',
            data: icecreamItem
        });
        } catch (err) {
            console.error('Unable to add ice cream to DynamoDB:', err);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    } 
    async updateOneIcecream(req, res, next) {
        const {id} = req.params;
        const newData    = req.body;
        try {
        const existingIcecream = await docClient.get({
            TableName: icecreamSchema.TableName,
            Key: { id: id }
        }).promise();

        if (!existingIcecream.Item) {
            return res.status(400).json({
                success: false,
                message: `Ice cream with ID '${icecreamItem.id}' is not founded`
            });
        }

        if (!validateIcecreamItem(newData)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid ice cream item attributes'
            });
        }

        delete newData.id;

        const expressionAttributeValues = {};
        Object.entries(newData).forEach(([key, value]) => {
            expressionAttributeValues[`:${key}`] = value;
        });

        // Construct the UpdateExpression dynamically
        const updateExpression = 'SET ' + Object.keys(newData).map(key => `${key} = :${key}`).join(', ');

        const params = {
            TableName: icecreamSchema.TableName,
            Key: { id: id },
            UpdateExpression: updateExpression,
            ExpressionAttributeValues: expressionAttributeValues,
            ReturnValues: 'ALL_NEW'
        };

        const updatedItem = await docClient.update(params).promise();

        res.json({
            success: true,
            message: 'Ice cream updated successfully',
            data: updatedItem.Attributes // Return the updated item
        });
    } catch (err) {
        console.error('Unable to update ice cream in DynamoDB:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
    }

    async deleteOneIcecream(req, res, next) {
        const {id} = req.params;

        try {
            // Check if the ice cream with the given ID exists
            const existingIcecream = await docClient.get({
                TableName: icecreamSchema.TableName,
                Key: { id: id }
            }).promise();
    
            if (!existingIcecream.Item) {
                return res.status(404).json({
                    success: false,
                    message: `Ice cream with ID '${id}' not found`
                });
            }
    
            // If the ice cream exists, delete it from the DynamoDB table
            await docClient.delete({
                TableName: icecreamSchema.TableName,
                Key: { id: id }
            }).promise();
    
            // Respond with success message
            res.json({
                success: true,
                message: `Ice cream with ID '${id}' deleted successfully`
            });
        } catch (err) {
            // Handle errors
            console.error('Unable to delete ice cream from DynamoDB:', err);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }
}

module.exports = IcecreamController;
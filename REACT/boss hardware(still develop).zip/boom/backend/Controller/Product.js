const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
const {productSchema, validateProductItem} = require('../model/Product');

class ProductController {
    async getAllProducts(req, res, next) {
        const params = {
            TableName: productSchema.TableName,
            Select: 'ALL_ATTRIBUTES',
        };

        try {
            const data = await docClient.scan(params).promise();
            res.json(data);
        } catch (err) {
            console.error('Unable to scan DynamoDB table:', err);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }
    
    async getOneProduct(req, res, next) {
        const { id } = req.params;
        try {
            const params = {
                TableName: productSchema.TableName,
                KeyConditionExpression: 'id = :id', // Specify the key condition
                ExpressionAttributeValues: {
                    ':id': id
                }
            };
            const data = await docClient.query(params).promise();
    
            if (data.Items.length === 0) {
                return res.status(404).json({ error: 'Product not found' });
            }
    
            // Assuming id is unique, return the first item in the result array
            const product = data.Items[0];
            res.json(product);
        } catch (err) {
            console.error('Unable to get product:', err);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }
    async addOneProduct(req, res, next) {
        try {
            const productItem = req.body;
        const itemId = productItem.name;

            
            // // Validate the incoming product item
            const isValidProductItem = validateProductItem(productItem);
            if (!isValidProductItem) {
                return res.status(400).json({
                    success: false,
                    message: 'Invalid product item attributes'
                });
            }

            // Check if the item with the same ID already exists
            const checkParams = {
                TableName: productSchema.TableName,
                KeyConditionExpression: 'id = :id',
                ExpressionAttributeValues: {
                    ':id': itemId
                }
            };

            const existingItem = await docClient.query(checkParams).promise();
            if (existingItem.Items.length > 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Product with this ID already exists'
                });
            }

    
            // Add the new item
            productItem.id = itemId;
    
            const params = {
                TableName: productSchema.TableName,
                Item: productItem
            };
    
            // Put the new item into DynamoDB
            await docClient.put(params).promise();
    
            res.status(201).json({
                success: true,
                message: 'Product added successfully',
                data: productItem
            });
        } catch (err) {
            console.error('Unable to add product to DynamoDB:', err);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }
    async updateProduct(req, res, next) {
        const { id } = req.params;
        const { name, type, URL } = req.body;
        
        try {
            const getParams = {
                TableName: productSchema.TableName,
                Key: { id }
            };
            
            const existingItem = await docClient.get(getParams).promise();
            if (!existingItem.Item) {
                return res.status(404).json({ error: 'Product not found' });
            }

            const updatedProductItem = {
                ...existingItem.Item,
                name,
                type,
                URL
            };

            const isValidProductItem = validateProductItem(updatedProductItem);
            if (!isValidProductItem) {
                return res.status(400).json({
                    success: false,
                    message: 'Invalid product item attributes'
                });
            }

            const updateParams = {
                TableName: productSchema.TableName,
                Key: { id },
                UpdateExpression: 'set #name = :name, #type = :type, #URL = :URL',
                ExpressionAttributeNames: {
                    '#name': 'name',
                    '#type': 'type',
                    '#URL': 'URL'
                },
                ExpressionAttributeValues: {
                    ':name': name,
                    ':type': type,
                    ':URL': URL
                },
                ReturnValues: 'ALL_NEW'
            };
            
            const result = await docClient.update(updateParams).promise();

            res.status(200).json({
                success: true,
                message: 'Product updated successfully',
                data: result.Attributes
            });
        } catch (err) {
            console.error('Unable to update product in DynamoDB:', err);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }
    async deleteProduct(req, res, next) {
    const { id } = req.params;

    try {
        const params = {
            TableName: productSchema.TableName,
            Key: {
                id: id
            }
        };

        // Delete the item from DynamoDB
        await docClient.delete(params).promise();

        res.status(200).json({
            success: true,
            message: 'Product deleted successfully'
        });
    } catch (err) {
        console.error('Unable to delete product from DynamoDB:', err);
        res.status(500).json({ error: 'Internal Server Error' });
    }
    
}
}
module.exports = ProductController;
const express = require('express');
const router = express.Router();
const ProductController = require('../Controller/Product');

const productController = new ProductController();

router.get('/api/products', productController.getAllProducts.bind(productController));

router.get('/api/product/:id', productController.getOneProduct.bind(productController));

router.post('/api/product', productController.addOneProduct.bind(productController));

router.put('/api/product/:id', productController.updateProduct.bind(productController));

router.delete('/api/product/:id', productController.deleteProduct.bind(productController));



module.exports = router;
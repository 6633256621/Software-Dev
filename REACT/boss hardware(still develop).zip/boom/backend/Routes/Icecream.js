const express = require('express');
const router = express.Router();
const IcecreamController = require('../Controller/Icecream');

// Create an instance of IcecreamController
const icecreamController = new IcecreamController();

// Define route to get all ice creams
router.get('/api/icecreams', icecreamController.getAllIcecreams.bind(icecreamController));

// Define route to get a single ice cream by ID
router.get('/api/icecream/:id', icecreamController.getOneIcecream.bind(icecreamController));

// Define route to add a new ice cream
router.post('/api/icecream', icecreamController.addOneIcecream.bind(icecreamController));

// Define route to update an existing ice cream
router.put('/api/icecream/:id', icecreamController.updateOneIcecream.bind(icecreamController));

// Define route to delete an ice cream
router.delete('/api/icecream/:id', icecreamController.deleteOneIcecream.bind(icecreamController));

module.exports = router;

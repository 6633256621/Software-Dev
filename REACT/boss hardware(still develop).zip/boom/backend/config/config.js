require('dotenv').config({ path: './config/config.env' });

module.exports = {
    port: process.env.PORT,
    region : process.env.AWS_REGION
}
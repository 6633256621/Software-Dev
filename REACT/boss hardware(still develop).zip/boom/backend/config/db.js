const AWS = require('aws-sdk');

const connectDB = async () => {
  try {
    AWS.config.update({
      region: process.env.AWS_REGION,
      accessKeyId: process.env.AWS_ACCESS_KEY_ID,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
    });
    const dynamodb = new AWS.DynamoDB();
    dynamodb.listTables({}, (err, data) => {
      if (err) {
        console.error('Unable to connect to DynamoDB:', err);
      } else {
        console.log('Successfully connected to DynamoDB. Tables:', data.TableNames);
      }
    });
  } catch (err) {
    console.error('Error connecting to DynamoDB:', err);
  }
};

module.exports = connectDB;

const express = require('express');
const app = express();
//config
const config = require('./config/config');
const IcecreamRouter = require('./Routes/Icecream');
const ProductRouter = require('./Routes/Product');
const cors = require('cors');
app.use(cors());


app.use(express.json());

//enable to send backend request

//use router
app.use(IcecreamRouter);
app.use(ProductRouter);


app.listen(config.port,console.log("Run on "+config.port));
const icecreamSchema = {
    TableName: 'icecreams', // The name of the DynamoDB table
    KeySchema: [
        { AttributeName: 'id', KeyType: 'HASH' } // The primary key attribute (id)
    ],
    AttributeDefinitions: [
        { AttributeName: 'id', AttributeType: 'S' }, // Define the type of the primary key attribute (String)
        { AttributeName: 'flavor', AttributeType: 'S' }, // Define the type of the flavor attribute (String)
        { AttributeName: 'price', AttributeType: 'N' } // Define the type of the price attribute (Number)
        // Add more attribute definitions as needed
    ]
};

function validateIcecreamItem(icecreamItem) {
  // Define expected attribute types based on the schema
  const expectedTypes = {
      id: 'string',
      flavor: 'string',
      price: 'number'
      // Add more attributes and their expected types as needed
  };

  // Check if all attributes have correct types
  for (const attr in icecreamItem) {
    // Check if the attribute is defined in the schema
    if (!expectedTypes[attr]) {
        return false; // Attribute not defined in schema
    }
    // Check if the attribute type matches the expected type
    if (typeof icecreamItem[attr] !== expectedTypes[attr]) {
        return false; // Attribute type mismatch
    }
}
  return true; // All attributes have correct types
}
module.exports = {icecreamSchema, validateIcecreamItem};

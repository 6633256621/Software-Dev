const productSchema = {
    TableName: 'product', // The name of the DynamoDB table
    KeySchema: [
        { AttributeName: 'id', KeyType: 'HASH' }
    ],
    AttributeDefinitions: [
        { AttributeName: 'id', AttributeType: 'S' }, // Define the type of the primary key attribute (String)
        { AttributeName: 'name', AttributeType: 'S' }, // Define the type of the sort key attribute (String)
        { AttributeName: 'type', AttributeType: 'S' }, // Define the type of the type attribute (String)
        { AttributeName: 'URL', AttributeType: 'S' }, // Define the type of the type attribute (String)
        { AttributeName: 'history', AttributeType: 'L' }, // Define the type of the history attribute (List)
        // Add more attribute definitions as needed
    ]
};

function validateProductItem(productItem) {
    const expectedTypes = {
        id: 'string',
        name: 'string',
        type: 'string',
        URL: 'string',
        history: 'array'
    };

    // Check if all attributes have correct types
    for (const attr in productItem) {
        // Check if the attribute is defined in the schema
        if (!expectedTypes[attr]) {
            console.log(1);
            return false; // Attribute not defined in schema
        }

        // Check if the attribute type matches the expected type
        if (expectedTypes[attr] === 'array' && !Array.isArray(productItem[attr])) {
            console.log(2);
            return false; // Attribute is expected to be an array but is not
        }
        else if (attr!=="history"&&typeof productItem[attr] !== expectedTypes[attr]) {
            console.log(3);
            return false; // Attribute type mismatch
        }

        // Additional check for types within 'history' array
        if (attr === 'history') {
            if (!productItem[attr].every(item => typeof item === 'object' && item !== null)) {
            console.log(4);
            return false; // Not all items in 'history' array are objects
            }
            // Check types of attributes within each object in 'history'
            for (const historyItem of productItem[attr]) {
                if (typeof historyItem.company !== 'string' ||
                    typeof historyItem.date !== 'string' ||
                    typeof historyItem.price !== 'number' ||
                    typeof historyItem.quan !== 'number' ||
                    typeof historyItem.discount !== 'number') {
            console.log(5);
            return false; // Types of attributes within history item do not match expected types
                }
            }
        }
    }

    return true; // All attributes have correct types
}


module.exports = {productSchema, validateProductItem};

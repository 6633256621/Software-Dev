import Banner from "@/components/bannerComponents/banner";
import PromoteCard from "@/components/PromoteCard";

export default function Home() {
  return (
    <main className="absolute inset-y-0 left-0 z-10 w-full">
      <Banner></Banner>
      {/* <PromoteCard></PromoteCard> */}
    </main>
  );
}

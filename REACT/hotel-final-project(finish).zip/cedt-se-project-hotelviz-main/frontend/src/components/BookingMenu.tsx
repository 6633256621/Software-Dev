import styles from './bookingmenu.module.css';

export default function BookingMenu() {
    return (
        <div className={styles.submenu}>
            Sub-Menu
        </div>
    )
}
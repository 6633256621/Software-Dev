'use client'
import Card from './Card';
import { useReducer } from 'react';
import Link from 'next/link';

export default function CardPanel () {

    const showRatingReducer = (
        ratingList: Map<string, number>,
        action: {
            type: string;
            hospitalName:string;
            rating?: number
        }
    ) => {
        switch (action.type) {
            case 'update': {
                ratingList.set(action.hospitalName, action.rating || 0)
                return new Map(ratingList)
            }
            case 'delete': {
                ratingList.delete(action.hospitalName);
                return new Map(ratingList)
            }
            default: return ratingList
        }
    }

    const [ratingList, dispatchRating] = useReducer(showRatingReducer, new Map([
        ['Chulalongkorn Hospital', 5],
        ['Rajavithi Hospital', 5],
        ['Thammasat University Hospital', 5],
    ]))

    const mockHospitalRepo = [{hid:"001",name:"Chulalongkorn Hospital", image:"/img/chula.jpg"},
                {hid:"002",name:"Rajavithi Hospital", image:"/img/rajavithi.jpg"},
                {hid:"003",name:"Thammasat University Hospital", image:"/img/thammasat.jpg"}]
    return (
        <div className='bg-slate-200 p-1'>
<div style={{margin:"20px",display:"flex",
      flexDirection:"row",alignContent:"start",
      justifyContent:"space-around"}}>

        {/* <Card hospitalName='Chulalongkorn Hospital' imgSrc='/img/chula.jpg' 
        rating={(hospitalName: string,rating?: number) => dispatchRating({
            type: 'update', 
            hospitalName:hospitalName,
            rating: rating
        })}
            mData={ratingList} />
        <Card hospitalName='Rajavithi Hospital' imgSrc='/img/rajavithi.jpg' 
        rating={(hospitalName: string,rating?: number) => dispatchRating({
            type: 'update', 
            hospitalName:hospitalName,
            rating: rating
        })}
        mData={ratingList} />
        
        <Card hospitalName='Thammasat University Hospital' imgSrc='/img/thammasat.jpg'
        rating={(hospitalName: string,rating?: number) => dispatchRating({
            type: 'update', 
            hospitalName:hospitalName,
            rating: rating
        })}
        mData={ratingList} /> */
        mockHospitalRepo.map((hospitalItem)=>(
            <Link href={`/hospital/${hospitalItem.hid}`} className='w-1/5'>
            <Card hospitalName={hospitalItem.name} imgSrc={hospitalItem.image}
        rating={(hospitalName: string,rating?: number) => dispatchRating({
            type: 'update', 
            hospitalName:hospitalName,
            rating: rating
        })}
        mData={ratingList} />
        </Link>
        )
        )
        
        }
      </div>
        <div>
        </div>
        {Array.from(ratingList).map(([hospital, rating]) =>
                <div key={hospital} data-testid = {hospital}
                    onClick={() => dispatchRating({ type: 'delete', hospitalName:hospital, rating })}>
                    {hospital} {rating}
                </div>)}
        </div>
    );
}
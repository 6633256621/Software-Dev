'use client'
import styles from './productcard.module.css'
import Image from 'next/image';
import InteractiveCard from './InteractiveCard';
import Rating from '@mui/material/Rating/'
import React,{ useState } from 'react';



export default function Card({hospitalName, imgSrc,rating,mData,}:{hospitalName :string,imgSrc:string,rating?:Function,mData?:Map<String,number>}) {

    const [ratingValue, setRatingValue] = useState<number | null>(5);

    const handleChange = (event: React.ChangeEvent<{}>, newValue: number | null) => {
        setRatingValue(newValue);
        if (rating) {
            rating(hospitalName, newValue); // Call rating function if it exists
        }
    };
    
    return (
        <InteractiveCard>
            <div className='w-full h-[70%] p-20 relative rounded-t-lg>'>
                <Image src={imgSrc}
                alt='Hospital Picture'
                fill={true}
                className='object-cover rounded-t-lg'
                />
            </div>
            <div className='w-[1/5] h-[2/5] p-[10px] relative'>
                    {hospitalName}<br></br>
                    <div className="w-full h-[15%] p-[7px] pt-[15px] text-blue-950"
            onClick={(e)=>{e.stopPropagation(); 
                if (rating) {
                    rating(hospitalName);
                }
            }}>
                <Rating
                    id= {hospitalName+' Rating'}
                    name= {hospitalName+' Rating'}
                    data-testid= {hospitalName+' Rating'}
                    value={mData?.get(hospitalName)}
                    onChange={handleChange}
                />
            </div> 
                    </div>
                       
        </InteractiveCard>
    );
}
import Link from "next/link"
import Card from "./Card"
import { HospitalItem } from "../../interfaces"
import { HospitalJson } from "../../interfaces"
export default async function HospitalCatalog({hospitalsJson}:{hospitalsJson:Promise<HospitalJson>}) {
    const hospitalsJsonResult = await hospitalsJson
    return (
        <>
        Explore {hospitalsJsonResult.count} models in our catalog
        <div style = {{margin:"20px",display:"flex",
        flexDirection:"row",alignContent:"space-around",
    justifyContent:"space-around",flexWrap:"wrap",padding:"10px"}}>
        {
            hospitalsJsonResult.data.map((hospitalItem:HospitalItem)=>(
                <Link href={`/hospitals/${hospitalItem.id}`} className="w-1/5">
                    <Card hospitalName={hospitalItem.name} imgSrc={hospitalItem.picture}/>
                </Link>
            ))
        }
    </div>
        </>
    )
}
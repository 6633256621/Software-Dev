"use client"
import BookingList from "@/components/BookingList"

export default function CartPage() {
    return (
        <main>
            <BookingList></BookingList>
        </main>
    )
}
package config;

public class Status {
    public static boolean speedBuff = false;
    public static boolean strengthBuff = false;
    public static boolean dexBuff = false;
}

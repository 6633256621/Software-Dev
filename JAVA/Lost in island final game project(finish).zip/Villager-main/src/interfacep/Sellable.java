package interfacep;

public interface Sellable {
    int getPrice();
}

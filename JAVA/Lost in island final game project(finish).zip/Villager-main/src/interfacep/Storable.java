package interfacep;

import object.items.Item;

import java.util.ArrayList;

public interface Storable {
    ArrayList<Item> getInventory();
}
